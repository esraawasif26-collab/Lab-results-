
import streamlit as st

st.set_page_config(page_title="معمل التحاليل", layout="wide")
st.image("logo.jpeg", width=100)
st.markdown("""
# معمل قطور الشامل
الهيئة العامة للتأمين الصحي - فرع الغربية

---
""" )

st.title("نموذج إدخال نتائج التحاليل")

# قائمة التحاليل
cbc_fields = {
    "WBC": "",
    "RBC": "",
    "Platelets": "",
    "MCV": "",
    "MCH": "",
    "MCHC": ""
}

st.subheader("CBC")
for test in cbc_fields:
    cbc_fields[test] = st.text_input(f"{test}")

st.subheader("تحاليل إضافية")
other_tests = [
    "RBS", "FBS", "2hPPS", "Uric acid", "LDH", "Alk.ph", "Albumin",
    "T.bilirubin", "D.bilirubin", "H.pylori Ag", "H.pylori Ab"
]
other_results = {test: st.text_input(test) for test in other_tests}

st.subheader("Lab to Lab")
lab_to_lab = [
    "AFP", "CEA", "CA19.5", "CA15.3", "FSH", "LH", "TSH", "T3", "T4", "FT3", "FT4", "iron", "HBA1C"
]
lab_to_lab_results = {test: st.text_input(test) for test in lab_to_lab}

st.subheader("تحاليل منفردة")
single_tests = ["cholesterol", "triglycerides", "LDL", "HDL"]
single_results = {test: st.text_input(test) for test in single_tests}

st.subheader("Viruses")
viruses = ["HCV", "HBS.Ag", "HIV 1/2"]
virus_results = {test: st.text_input(test) for test in viruses}

st.subheader("Coagulation")
coagulation = ["PT", "PTT", "aPTT"]
coag_results = {test: st.text_input(test) for test in coagulation}

st.subheader("Bacteriology")
bacteriology = ["urine analysis", "stool analysis", "culture"]
bacteriology_results = {test: st.text_input(test) for test in bacteriology}

if st.button("توليد التقرير"):
    st.success("تم إدخال البيانات بنجاح")
    st.write("**CBC:**", cbc_fields)
    st.write("**تحاليل إضافية:**", other_results)
    st.write("**Lab to Lab:**", lab_to_lab_results)
    st.write("**تحاليل منفردة:**", single_results)
    st.write("**Viruses:**", virus_results)
    st.write("**Coagulation:**", coag_results)
    st.write("**Bacteriology:**", bacteriology_results)

st.markdown("---")
st.markdown("**Sign by:** ...................................", unsafe_allow_html=True)
